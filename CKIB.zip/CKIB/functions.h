#ifndef FUNCTIONS.H
#define FUNCTIONS.H

void Servo_attach(void) {
		MDR_RST_CLK->PER_CLOCK |= (1<<21); //initialization PORTA 
		MDR_RST_CLK->PER_CLOCK |= (1 << 14); //initialization TIM_CLK_1
		MDR_RST_CLK->TIM_CLOCK |= (1 << 24);
	
    //PIN PA1 configuration (PWM)
    MDR_PORTA->OE     |=  (1 << PIN_SERVO_POS);
    MDR_PORTA->FUNC   &= ~(0x3 << 2*PIN_SERVO_POS);
    MDR_PORTA->FUNC   |=  (0x2 << 2*PIN_SERVO_POS);
    MDR_PORTA->ANALOG |=  (1 << PIN_SERVO_POS);
    MDR_PORTA->PWR    |=  (0x3 << 2*PIN_SERVO_POS);
    
    //TIM_CLK_1 configuration (PWM)
    MDR_TIMER1->CNTRL = 0; //of
    MDR_TIMER1->PSG   = 80 - 1;           // Delitel = 1 mks
    MDR_TIMER1->ARR   = 2000 - 1;         // Period = 20ms 

    MDR_TIMER1->CH3_CNTRL = (0x6 << 9);  //config
		MDR_TIMER1->CH3_CNTRL  |= (1 << 8); //on
    MDR_TIMER1->CH3_CNTRL1 = 0x9;

    MDR_TIMER1->CCR3 = 0; //nach pologenie 0
    MDR_TIMER1->CNTRL |= (1 << 0); //on
}





#endif