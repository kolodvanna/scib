
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'CKIB' 
 * Target:  'Target_1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "MDR32F9Q2I.h"

/* Target microcontroller definition */
#define USE_MDR32F9Q2I

#endif /* RTE_COMPONENTS_H */
